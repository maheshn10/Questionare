export const TodoTypes = {
    GETTODOS: "GETTODOS",
    INSERTTODO: "INSERTTODO",
    DELETETODO: "DELETETODO",
    TOGGLETODO: "TOGGLETODO"
}

export const FilterTypes = {
    FILTERBY: "FILTERBY"
}